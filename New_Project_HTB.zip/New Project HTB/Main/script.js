const form = document.querySelector('.login-form');
const url = `https://server.fut-game.epizy.com/htbchallenge`;
const finishUrl = `https://server.fut-game.epizy.com/finish`;

form.addEventListener('submit', function (event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.onload = function () {
        const data = JSON.parse(xhr.responseText);
        if (username === "root" && password === data['password']) {
            const xhr2 = new XMLHttpRequest();
            xhr2.open('POST', finishUrl);
            xhr2.setRequestHeader('Content-Type', 'application/json');
            const body = {
                password: password
            };
            xhr2.send(JSON.stringify(body));
            xhr2.onload = function () {
                const response = JSON.parse(xhr2.responseText);
                if (response.flag) {
                    alert(response.flag);
                } else {
                    console.log('Something went wrong');
                }
            }
        } else if (username !== "root") {
            console.log("No permissions!");
        } else {
            console.log("Wrong password!");
        }
    };
    xhr.send();
});
